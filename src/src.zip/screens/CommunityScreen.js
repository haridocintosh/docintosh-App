import React from 'react'
import { View, Text,StyleSheet,TouchableOpacity,Pressable } from 'react-native'

const FavoriteScreen = () => {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
    <View style={{borderRadius:20/2, width:100, height:50, backgroundColor:'#fff' }}>
    <Text>Slect Me </Text>
 
    </View>
    </View>
  )
}

export default FavoriteScreen