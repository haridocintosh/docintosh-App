import React from 'react'
import { View, Text } from 'react-native'

const GameDetailsScreen = ({navigation, route}) => {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text></Text>
      <Text></Text>
    </View>
  )
}

export default GameDetailsScreen
