export const mainApi = {
    baseUrl: 'https://docintosh.com',
    session: {
      ud: 'userData',
    },
  };
  